import { NextFunction } from 'express';
import { Point, Shape, Type } from './shape.model'
import { Rect } from './rect.model'
import { ConsoleLogger } from '@nestjs/common';

export class Line implements Shape {
  readonly line1_point1: Point;
  readonly line1_point2: Point;
  readonly center: Point;
  readonly line2_point1: Point;
  readonly type: Type;

  constructor(x: number, y: number, x1: number, y2: Number) {
    // line 1 points

    this.line1_point1 = <Point>{ x, y };
    this.line1_point2 = <Point>{ x, y };

    this.center = <Point>{ x, y };
    this.type = Type.LINE;
  }

  collides(other: Shape): boolean {
    switch (other.type) {
      case Type.CIRCLE:
        throw new Error('Implement Circle to Line collision checking');
      case Type.RECT:
        // throw new Error('Implement Rectangle to Line collision checking');
        const rect: Rect = Rect.fromShape(other);

        let all_points = return_all_four_points(rect.center.x, rect.center.y, rect.width, rect.height);

        //max x co-oridinate ;
        let rectangleMaxX;
        let rectangleMinX;
        let rectangleMaxY;
        let rectangleMinY;

        if (all_points.x2 > all_points.x1) {
          rectangleMaxX = all_points.x2;
          rectangleMinX = all_points.x1;
        } else {
          rectangleMinX = all_points.x2;
          rectangleMaxX = all_points.x1;
        }

        if (all_points.y2 > all_points.y1) {
          rectangleMaxX = all_points.y2;
          rectangleMinX = all_points.y1;
        } else {
          rectangleMaxX = all_points.y1;
          rectangleMinX = all_points.y2;
        }

        let minX = this.line1_point1.x;
        let maxX = this.line1_point2.x;

        if (this.line1_point1.x > this.line1_point2.x) {
          minX = this.line1_point2.x;
          maxX = this.line1_point1.x;
        }

        // Find the intersection of the segment's and rectangle's x-projections
        if (maxX > rectangleMaxX) {
          maxX = rectangleMaxX;
        }

        if (minX < rectangleMinX) {
          minX = rectangleMinX;
        }

        if (minX > maxX) // If their projections do not intersect return false
        {
          return false;
        }

        // Find corresponding min and max Y for min and max X we found before
        let minY = this.line1_point1.y;
        let maxY = this.line1_point2.y;

        let dx = this.line1_point2.x - this.line1_point1.x;

        if (Math.abs(dx) > 0.0000001) {
          let a = (all_points.y2 - all_points.y1) / dx;
          let b = all_points.y1 - a * this.line1_point1.x;
          minY = a * minX + b;
          maxY = a * maxX + b;
        }

        if (minY > maxY) {
          let tmp = maxY;
          maxY = minY;
          minY = tmp;
        }

        // Find the intersection of the segment's and rectangle's y-projections
        if (maxY > rectangleMaxY) {
          maxY = rectangleMaxY;
        }

        if (minY < rectangleMinY) {
          minY = rectangleMinY;
        }

        if (minY > maxY) // If Y-projections do not intersect return false
        {
          return false;
        }

        return true;

      case Type.LINE:
        // throw new Error('Implement Line to Line collision checking');

        // p1 is one endpoint of line 1

        const line2_point1: Line = Line.fromShape(other);

        const line2_point2: Line = Line.fromShape(other);

        let p1 = this.line1_point1;
        let p2 = this.line1_point2;
        let q1 = line2_point1;
        let q2 = line2_point2;
        let o1 = orientation(p1, q1, p2);
        let o2 = orientation(p1, q1, q2);
        let o3 = orientation(p2, q2, p1);
        let o4 = orientation(p2, q2, q1);

        // General case
        if (o1 != o2 && o3 != o4)
          return true;

        // Special Cases
        // p1, q1 and p2 are collinear and p2 lies on segment p1q1
        if (o1 == 0 && onSegment(p1, p2, q1)) return true;

        // p1, q1 and q2 are collinear and q2 lies on segment p1q1
        if (o2 == 0 && onSegment(p1, q2, q1)) return true;

        // p2, q2 and p1 are collinear and p1 lies on segment p2q2
        if (o3 == 0 && onSegment(p2, p1, q2)) return true;

        // p2, q2 and q1 are collinear and q1 lies on segment p2q2
        if (o4 == 0 && onSegment(p2, q1, q2)) return true;

        return false; // Doesn't fall in any of the above cases
      default:
        throw new Error(`Invalid shape type!`);
    }
  }

  /**
   * Typecasts a Shape object into this Shape type
   * @param other the Shape object
   * @returns a Line object
   */
  static fromShape(other: Shape): Line {
    const polymorph = <any>other;
    // if (!polymorph.center.x || !polymorph.center.y) {
    //   throw new Error('Shape is invalid! Cannot convert to a Rectangle');
    // }

    return new Line(
      polymorph.center.x,
      polymorph.center.y,
      polymorph.center.x1,
      polymorph.center.y1,
    );
  }
}

function orientation(p, q, r) {

  //check if points are clockwise or anti-clockwise
  let val = (q.y - p.y) * (r.x - q.x) -
    (q.x - p.x) * (r.y - q.y);

  if (val == 0) return 0; // collinear

  return (val > 0) ? 1 : 2; // clock or counterclock wise
}

// / Given three collinear points p, q, r, the function checks if
// point q lies on line segment 'pr'
function onSegment(p, q, r) {
  if (q.x <= Math.max(p.x, r.x) && q.x >= Math.min(p.x, r.x) &&
    q.y <= Math.max(p.y, r.y) && q.y >= Math.min(p.y, r.y))
    return true;

  return false;
}

function return_all_four_points(x, y, width, height) {

  //starting points
  let x1 = x;
  let y1 = y;

  let x2 = x;
  let y2 = y + width;

  let x4 = x2 + height;
  let y4 = y2;

  let x3 = x4;
  let y3 = y - height;

  return { x1, y1, x2, y2, x3, y3, x4, y4 }

};