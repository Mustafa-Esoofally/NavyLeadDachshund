//import distance between function 
import { distanceBetween, Point, Shape, Type } from './shape.model'
//import circle model
import { Circle } from './circle.model'
export class Rect implements Shape {
  readonly center: Point;
  readonly width: number;
  readonly height: number;
  readonly type: Type;

  constructor(x: number, y: number, width: number, height: number) {
    this.center = <Point>{ x, y };
    this.type = Type.RECT;
    this.width = width;
    this.height = height;
  }

  collides(other: Shape): boolean {
    switch (other.type) {
      case Type.CIRCLE:
        // throw new Error('Implement Rectangle to Circle collision checking');
        // Find the nearest polet on the rectangle to the center of rectange
        const circle: Circle = Circle.fromShape(other);
        const target: Point = this.center;
        const pointDistance: Point = <Point>{
          x: Math.abs(this.center.x - target.x),
          y: Math.abs(this.center.y - target.y),
        };

        if (pointDistance.x > this.width / 2 + circle.radius) {
          return false;
        } else if (pointDistance.y > this.height / 2 + circle.radius) {
          return false;
        } else if (pointDistance.x <= this.width / 2) {
          return true;
        } else if (pointDistance.y <= this.height / 2) {
          return true;
        }

        const circleToRectDistance =
          Math.pow(pointDistance.x - this.width / 2, 2) +
          Math.pow(pointDistance.y - this.height / 2, 2);

        return circleToRectDistance <= Math.pow(circle.radius, 2);
        
      case Type.RECT:
        // throw new Error('Implement Rectangle to Rectangle collision checking');
        
        const _other = <Rect>(<any>other);
        
        //get all foure points of rectangle 1 
        let rect1 = return_all_four_points(_other.center.x,_other.center.y,_other.width,_other.height)
        
        //get all foure points of rectangle 1 
        let rect2 = return_all_four_points(this.center.x,this.center.y,this.width,this.height)
        
        // l1.x == r1.x || l1.y == r1.y || l2.x == r2.x
        // || l2.y == r2.y
        
        if (rect1.x1 == rect2.x1 || rect1.y1 == rect2.y1 ||
          rect1.x2 == rect2.x2 || rect1.y2 == rect2.y2) {
              // the line cannot have positive overlap
              return false;
          }
   
          // If one rectangle is on left side of other
          if (rect1.x1 >= rect2.x1 || rect1.x2 >= rect2.x2) {
              return false;
          }
   
          // If one rectangle is above other
          if (rect2.y1 >= rect1.y2 || rect2.y1 >= rect1.y1) {
              return false;
          }
   
          return true;
      default:
        throw new Error(`Invalid shape type!`);
    }
  }

  /**
   * Typecasts a Shape object into this Shape type
   * @param other the Shape object
   * @returns a Rect object
   */
  static fromShape(other: Shape): Rect {
    const polymorph = <any>other;
    if (!polymorph.width || !polymorph.height) {
      throw new Error('Shape is invalid! Cannot convert to a Rectangle');
    }

    return new Rect(
      polymorph.center.x,
      polymorph.center.y,
      polymorph.width,
      polymorph.height,
    );

    // return_all_four_points = function(x,y,width,height) {
      //  ... }
    
  }
}

function return_all_four_points(x,y,width,height) {

  let x1=x;
  let y1=y;
  let x2=x+width;
  let y2=y+height;
  let x3=x+height;
  let y3=y;
  let x4=x;
  let y4=y +width;

  return {x1,y1,x2,y2,x3,y3,x4,y4}

};
